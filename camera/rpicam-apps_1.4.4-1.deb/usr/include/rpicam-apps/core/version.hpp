/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (C) 2021, Raspberry Pi (Trading) Ltd.
 *
 */
#pragma once

#include <string>

const std::string& RPiCamAppsVersion();
